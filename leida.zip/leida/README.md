# AETHER · vivo X300 探测站 (v19 · 诚实内核)

手机网页应用：用相机、麦克风/喇叭、IMU、磁力计做**本地**的目标识别、主动声呐测距、航迹推算和点云建图。所有计算都在设备上完成，不上传。

> 原则：**没有真实读数就显示「—」，绝不编造数字。** 本站没有演示模式，也没有模拟/随机数据：在电脑上打开会看到空场景，接上手机传感器才有读数。

## 哪些是真的，哪些不是

| 能力 | 数据来源 | 说明 |
|---|---|---|
| 目标识别 | **真实** · COCO-SSD（本地 TF.js） | 80 类；框 + 类别 + 置信度 |
| 目标距离 | **估算** · 类别典型高度 + 针孔模型 | 每个目标带 ±σ；不是测距。截断框、未知类别误差更大 |
| 声呐测距 | **真实** · 喇叭发 18–21.5 kHz chirp，麦克风匹配滤波 | 以直达声为时间零点，不依赖音频延迟；没听到回波返回失败原因而非数字 |
| 航迹 PDR | **真实** · 加速度计计步 + 罗盘航向 | 误差随距离累积（约 3–10%）。无罗盘时不计步 |
| 磁场异常 | **真实** · Magnetometer / 自适应基线 | 异常期间基线冻结 |
| 点云 / 占用栅格 | **真实累积** | 视觉投影、声呐落点、航迹；体素去重 + 对数几率栅格 |
| 场景分类 | **真实** · 画面亮度/纹理/环境光 | 8 帧滞回防抖 |
| Wi-Fi RSSI 与「无线环境扰动」 | **真实** · 经 Termux 桥接读取 | 当前连接 + 周边 AP 各自学习基线，偏离判扰动。它说明无线环境在变，**不能**判断墙后有没有人；CSI 普通 Android 应用拿不到。未连桥接时显示「—」 |
| 电量 | **真实** · Battery API，或桥接的 termux-battery-status | |
| 距离融合 | **真实来源的逆方差融合** | 只融合声呐与视觉估距，没有来源时显示「—」 |

**已删除（因为做不到真实）：** 演示/孪生模式、模拟穿墙人体与呼吸率、模拟场景物体、「最近金属」（无真实目标库）、合成孔径 SAR 卡片（PDR 精度远低于波长，无法相干成像）。

## Termux 桥接（Wi-Fi RSSI）

浏览器没有读取 Wi-Fi 信号强度的 API。`bridge/termux-bridge.mjs` 是一个零依赖的 Node 小服务，在手机的 Termux 里运行，把 `termux-api` 的读数通过 WebSocket 推给网页：

```bash
pkg install nodejs termux-api        # 另需安装 Termux:API 应用并授予定位权限（扫描 Wi-Fi 需要）
node bridge/termux-bridge.mjs --origin https://你的站点域名
# 打印 ws://127.0.0.1:8765/ws?token=… ，粘贴到「硬件」页的 Termux 桥接框里连接
```

安全模型：只监听 127.0.0.1；每次启动随机 128 位令牌（常数时间比较）+ 严格 Origin 白名单（默认只放行 localhost / 127.0.0.1，其它站点必须用 `--origin` 显式授权）；最多 4 个连接；单帧 ≤ 4 KB 且只接受 `ping`；只执行写死参数的三条只读命令（`termux-wifi-connectioninfo` 1 s、`termux-wifi-scaninfo` 5 s、`termux-battery-status` 30 s），不经过 shell；没有客户端连接时完全不轮询。桥接地址（含令牌）只保存在浏览器 localStorage，会话导出不包含它。`bridge/termux-bridge.test.mjs` 与 `src/lib/core/{wifi-change,bridge-protocol}.test.ts` 覆盖协议、鉴权与检测算法。

## 页面

- **指挥台** 总览：融合距离（逆方差，带冲突标记）、传感器状态、告警、关键曲线。
- **视觉** 相机、检测设置、跟踪列表（ID / 深度 ±σ / 依据 / 方位）、OCR（中英）、条码、截图。
- **声呐** 发射、回波包络（含命中标记）、参数（温度、间距、量程、最小 SNR、平均、增益）、已知距离校准、脉冲日志。
- **电磁与运动** 磁力计三轴 + 异常基线、Wi-Fi 链路（经桥接）、IMU、蓝牙、GNSS、计步。
- **3D 环境图** 点云（按类别过滤）、占用栅格、航迹；导出/导入 JSON 会话、导出 PLY。
- **环境自适应 / 硬件 / 日志**。

## 声呐原理（简要）

1. 发射 45 ms Hann 窗线性调频（18 → 21.5 kHz）。
2. 麦克风录到的信号与发射模板做匹配滤波；最强峰 = 喇叭→麦克风直达声。
3. 用分数延迟模板消去直达声后，在其后寻找回波。`R = (间距 + c·Δt) / 2`，c 随温度。
4. SNR = 峰值 / 本底中位数。回波 ≥ 最小 SNR（默认 8 dB）且直达声 ≥ 12 dB 才算命中。
5. 多次发射取中位数；`校准` 用已知距离反推喇叭—麦克风间距。

麦克风以「原始模式」打开（关闭回声消除、降噪、AGC），并检查浏览器是否真的接受。

## 坐标系

x 东、y 上、z 北；航向自 +z 顺时针。相机水平视场角默认 75°，可在视觉页调整。

## 开发

```bash
npm install
npm run dev          # http://localhost:8080
npm run typecheck    # tsc --noEmit
npm test             # 含 src/lib/core 的单元测试
node --experimental-strip-types --test src/lib/core/*.test.ts   # 仅核心算法测试
node --test bridge/termux-bridge.test.mjs                        # 桥接测试
npm run build
```

- `src/lib/core/` 是**纯算法内核**（无 DOM/React 依赖，可在 Node 里测）：DSP、声呐、罗盘、PDR、磁力、相机模型、跟踪、点云、占用栅格、融合、环境分类、告警、设置、会话 schema。
- `src/lib/radar-store.ts` 是唯一的状态中枢（10 Hz 主循环 + 1 Hz 维护）。
- `scripts/vendor-assets.mjs` 在 dev/build 时把 COCO-SSD 模型与 Tesseract 引擎/语言包下载到 `public/vendor/`（已 gitignore），应用从同源加载；下载失败时视觉回退到默认远程模型。
- 字体通过 `@fontsource` 打包，无外链。

## 需要真机验证的部分

沙箱里没有手机硬件，下列阈值是按物理推导 + 合成信号测试设定的，**需要在 vivo X300 上实测并调参**：

- 声呐：喇叭→麦克风泄漏强度、最小 SNR、浏览器是否真正关闭了回声消除（页面会提示）。
- 计步：步态阈值、步长（可调，默认 0.7 m）。
- 磁力计：手机/保护壳的静磁背景、Chrome 对 Magnetometer 的可用性。
- iOS：需要点「启用传感器」触发运动/方向权限。

## CI

`docs/ci.yml.example` 是现成的 GitHub Actions 配置（tsc + 核心测试 + build）。需要有 `workflows` 权限的账号把它复制到 `.github/workflows/ci.yml`。

## 文档

- `docs/ANALYSIS_v18_ROADMAP.md` 分析与路线图
- `docs/BUGS_AND_OPTIMIZATIONS.md` / `.csv` 109 项问题与优化清单（含编号）

## 未做（路线图）

- Wi-Fi CSI：普通 Android 应用拿不到（需 root / 定制固件），不支持。
- 相干 SAR 成像、SLAM 回环：需要厘米级相位相干定位，手机 IMU + PDR 做不到；已删除相关界面，不再声称。
- v16 后端：由上面的 Termux 桥接取代（本地、只读、无持久化）。

## v19 自研算法

声呐 DSP、3D 渲染、状态仓库、校验、点云/栅格、运动检测、推理调度、OCR 预处理和二维码解码都是自研实现，详见 [docs/V19_SELF_BUILT.md](docs/V19_SELF_BUILT.md)。保留的第三方：tfjs + COCO-SSD（模型权重）和 Tesseract（字符识别）。
